import psutil
from tkinter import *

window = Tk()
window.title("Окно с нагрузкой GPU")
window.geometry("780x680")

CPU_frame = Frame(window, borderwidth=1, relief=SOLID)
CPU_frame.pack(anchor="n", padx=10, pady=10)


while True:
    percent = psutil.cpu_percent(interval=None)
    physic_processing = psutil.cpu_count(logical=True)
    using_CPU = len(psutil.Process().cpu_affinity())
    statistics = psutil.cpu_stats()
    loading_CPU = psutil.getloadavg()

        # Лейбл CPU

    load_label = Label(CPU_frame, text=f"Нагрузка процессора: {percent}", fg='green')
    load_label.pack(anchor="w", padx=10, pady=10)
    if percent > 50:
        load_label.config(fg='red')
    else:
        load_label.config(fg="yellow")

    print(load_label)


    physic_processing_label = Label(CPU_frame, text=f"Кол-во физ.ядер: {physic_processing}")
    physic_processing_label.pack(anchor="w", padx=10, pady=10)

    using_CPU_label = Label(CPU_frame, text=f"Кол-во используемых ядер: {using_CPU}")
    using_CPU_label.pack(anchor="w", padx=10, pady=10)

    ctx_switches = Label(CPU_frame, text=f"Кол-во переключений контекста: {statistics[0]}") # лейбл, который отображает какое то кол-во переключений контекста
    ctx_switches.pack(anchor="w", padx=10, pady=10)

    interrupts = Label(CPU_frame, text=f"Кол-во прерываний с момента загрузки:{statistics[1]}")
    interrupts.pack(anchor="w", padx=10, pady=10)

    soft_interrupts = Label(CPU_frame, text=f"Кол-во программных прерываний с момента загрузки:{statistics[2]}")
    soft_interrupts.pack(anchor="w", padx=10, pady=10)

    syscalls = Label(CPU_frame, text=f"Кол-во системных вызово с момента загрузки: {statistics[3]}")
    syscalls.pack(anchor="w", padx=10, pady=10)

    loading_CPU_label = Label(CPU_frame, text=f"Средняя загрузка системы: {loading_CPU}")
    loading_CPU_label.pack(anchor="w", padx=10, pady=10)


    window.mainloop()